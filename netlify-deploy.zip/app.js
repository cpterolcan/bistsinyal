/* ============================================================
   BIST SİNYAL TAKİP — app.js  v2
   Yeni: Grafik modal (TradingView embed) + Dark mode + Arşiv
   ============================================================ */

// ── STORAGE ──────────────────────────────────────────────────
const DB = {
  get: (k, d=null) => { try { const v=localStorage.getItem(k); return v?JSON.parse(v):d; } catch { return d; } },
  set: (k, v)      => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

// ── STATE ─────────────────────────────────────────────────────
let state = {
  signals:   [],
  positions: DB.get('positions', []),
  watchlist: DB.get('watchlist', []),
  archive:   DB.get('archive', []),   // [{date, signals:[{ticker,price,k,d,...}]}]
  settings:  DB.get('settings', { backendUrl:'', defaultTarget:12, defaultStop:7 }),
  filter:    'all',
  currentModal: null,
  editIndex:    null,
  chartTicker:  null,
  chartInterval:'60',
  theme: DB.get('theme', 'auto'),  // 'light' | 'dark' | 'auto'
};

// ── DEMO SİNYALLER ────────────────────────────────────────────
const DEMO = [
  {ticker:'DAPGM',name:'DAP Gayrimenkul',      price:10.30,chg:8.42,k:8.2, d:5.1, sector:'Finans',      vol:'63M', hot:true },
  {ticker:'BTCIM',name:'Batıçim Çimento',       price:6.40, chg:5.09,k:11.4,d:7.8, sector:'Mineraller',  vol:'40M', hot:true },
  {ticker:'KLRHO',name:'Kiler Holding',          price:97.15,chg:9.96,k:6.3, d:3.9, sector:'Tüketici',    vol:'12M', hot:true },
  {ticker:'TTKOM',name:'Türk Telekom',           price:61.45,chg:0.33,k:18.9,d:15.7,sector:'İletişim',    vol:'17M', hot:false},
  {ticker:'TAVHL',name:'TAV Havalimanları',      price:262.0,chg:4.07,k:14.8,d:10.2,sector:'Taşımacılık', vol:'1.7M',hot:false},
  {ticker:'TRMET',name:'TR Anadolu Metal',       price:113.9,chg:5.56,k:9.7, d:6.4, sector:'Mineraller',  vol:'3.7M',hot:true },
  {ticker:'KLSYN',name:'Koleksiyon Mobilya',     price:11.79,chg:7.38,k:12.1,d:8.8, sector:'Tüketici',    vol:'3.3M',hot:false},
  {ticker:'MOPAS',name:'Mopas Marketcilik',      price:41.26,chg:3.77,k:15.6,d:12.3,sector:'Perakende',   vol:'2.4M',hot:false},
  {ticker:'FORTE',name:'Forte Bilgi İletişim',   price:95.15,chg:2.75,k:16.2,d:13.0,sector:'Teknoloji',   vol:'1.8M',hot:false},
  {ticker:'AYDEM',name:'Aydem Enerji',            price:25.76,chg:4.12,k:13.4,d:10.1,sector:'Enerji',      vol:'1.5M',hot:false},
  {ticker:'OYAKC',name:'Oyak Çimento',            price:20.96,chg:0.67,k:17.3,d:14.1,sector:'Mineraller',  vol:'10M', hot:false},
  {ticker:'CONSE',name:'Consus Enerji',           price:2.97, chg:2.41,k:13.8,d:10.5,sector:'Enerji',      vol:'5.1M',hot:false},
  {ticker:'KLGYO',name:'Kiler GYO',              price:4.92, chg:1.86,k:16.7,d:13.4,sector:'Finans',      vol:'5.2M',hot:false},
  {ticker:'AFYON',name:'Afyon Çimento',           price:13.10,chg:3.15,k:15.1,d:11.9,sector:'Mineraller',  vol:'1.7M',hot:false},
  {ticker:'TRENJ',name:'TR Dogal Enerji',         price:86.90,chg:3.89,k:14.9,d:11.7,sector:'Enerji',      vol:'1.1M',hot:false},
];

// Demo arşiv (geçmiş günler)
const DEMO_ARCHIVE = [
  { date:'01.06.2026', signals:[
    {ticker:'THYAO',price:296.4,k:7.2,d:4.8,chg:2.8,gainSince:5.1,sector:'Taşımacılık'},
    {ticker:'GARAN',price:102.4,k:9.1,d:6.3,chg:1.4,gainSince:9.3,sector:'Finans'},
    {ticker:'EREGL',price:41.82,k:11.8,d:8.4,chg:0.9,gainSince:3.8,sector:'Sanayi'},
  ]},
  { date:'30.05.2026', signals:[
    {ticker:'KCHOL',price:188.1,k:5.2,d:3.8,chg:3.2,gainSince:12.7,sector:'Holding'},
    {ticker:'TUPRS',price:310.5,k:8.9,d:6.1,chg:1.7,gainSince:7.4,sector:'Enerji'},
  ]},
  { date:'29.05.2026', signals:[
    {ticker:'ISCTR',price:18.92,k:14.3,d:11.1,chg:2.1,gainSince:6.2,sector:'Finans'},
    {ticker:'AKBNK',price:72.50,k:16.8,d:13.2,chg:0.8,gainSince:4.1,sector:'Finans'},
    {ticker:'PETKM',price:14.62,k:12.4,d:9.7,chg:1.3,gainSince:2.9,sector:'Kimya'},
  ]},
];

// ── THEME ─────────────────────────────────────────────────────
function applyTheme(theme) {
  state.theme = theme;
  DB.set('theme', theme);
  const dark = theme === 'dark' || (theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.body.classList.toggle('dark', dark);
  const icon = document.getElementById('theme-icon');
  if (icon) icon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

function toggleTheme() {
  const dark = document.body.classList.contains('dark');
  applyTheme(dark ? 'light' : 'dark');
}

// ── HELPERS ───────────────────────────────────────────────────
const AVC = ['av-g','av-b','av-a','av-p'];
function avClass(i) { return AVC[i % 4]; }

function strengthDots(k) {
  const s = k < 5 ? 5 : k < 10 ? 4 : k < 15 ? 3 : k < 18 ? 2 : 1;
  return Array.from({length:5}, (_,i) =>
    `<div class="ss-d ${i < s ? (s >= 4 ? 'on' : 'on am') : ''}"></div>`
  ).join('');
}

function miniBars(chg) {
  const h = [8,6,10,7,13, chg > 0 ? 22 : 5];
  return h.map((v,i) => `<div class="b ${i===5&&chg<0?'neg':''}" style="height:${v}px"></div>`).join('');
}

function todayStr() {
  return new Date().toLocaleDateString('tr-TR', {day:'2-digit',month:'2-digit',year:'numeric'});
}

// ── RENDER SIGNALS ────────────────────────────────────────────
function renderSignals() {
  let list = [...state.signals];
  if (state.filter === 'strong') list = list.filter(s => s.k < 10);
  else if (state.filter === 'fin')  list = list.filter(s => ['Finans','İletişim'].includes(s.sector));
  else if (state.filter === 'ener') list = list.filter(s => ['Enerji','Mineraller'].includes(s.sector));

  document.getElementById('signal-count').textContent = state.signals.length;
  document.getElementById('signal-date').textContent  = todayStr();
  const avgK = list.length ? (list.reduce((a,s) => a+s.k, 0)/list.length).toFixed(1) : '—';
  document.getElementById('avg-k').textContent = avgK;

  const container = document.getElementById('signal-list');
  if (!list.length) {
    container.innerHTML = `<div class="empty"><i class="fa-solid fa-satellite-dish"></i><strong>Sinyal bekleniyor</strong>TradingView webhook kurulduktan sonra sinyaller burada görünür.</div>`;
    return;
  }

  container.innerHTML = list.map((s, i) => `
    <div class="hcard ${s.hot ? 'hot' : 'warm'}">
      <div class="hcard-top">
        <div class="avatar ${avClass(i)}">${s.ticker.slice(0,5)}</div>
        <div class="hinfo">
          <div class="hname">${s.ticker} <span class="hsector">${s.sector}</span></div>
          <div class="hmeta">K: ${s.k.toFixed(1)} · D: ${s.d.toFixed(1)} · Hacim: ${s.vol}</div>
          <div class="ss">${strengthDots(s.k)}</div>
        </div>
        <div class="hright">
          <div class="hprice">₺${s.price.toFixed(2)}</div>
          <div class="hchg up">+${s.chg.toFixed(2)}%</div>
          <div class="bars">${miniBars(s.chg)}</div>
        </div>
      </div>
      <div class="hcard-actions">
        <div class="act-btn blue" onclick="openChart('${s.ticker}',${s.price},${s.k},${s.d})">
          <i class="fa-solid fa-chart-candlestick"></i> Grafik
        </div>
        <div class="act-btn green" onclick="openModal('${s.ticker}',${s.price},${s.k},${s.d})">
          <i class="fa-solid fa-plus"></i> Pozisyon
        </div>
        <div class="act-btn gray" onclick="addToWatchlist('${s.ticker}',${s.price},${s.k},${s.d})">
          <i class="fa-regular fa-eye"></i> İzle
        </div>
      </div>
    </div>
  `).join('');

  updateLastUpdate();
}

// ── CHART MODAL ───────────────────────────────────────────────
function openChart(ticker, price, k, d) {
  const theme = document.body.classList.contains('dark') ? 'dark' : 'light';
  location.href = `chart.html?ticker=${ticker}&price=${price}&k=${k}&d=${d}&theme=${theme}`;
}

function loadTVChart(ticker, interval) {
  const wrap = document.getElementById('tv-chart-wrap');
  const dark  = document.body.classList.contains('dark');
  const theme = dark ? 'dark' : 'light';

  // TradingView Advanced Chart Widget embed
  // EMA 50, EMA 100, Stochastic RSI studies dahil
  const studies = encodeURIComponent(JSON.stringify([
    { id:'MAExp@tv-basicstudies', inputs:{ length:50 }, styles:{ 'Plot':{ color:'#f59e0b', linewidth:2 } } },
    { id:'MAExp@tv-basicstudies', inputs:{ length:100 }, styles:{ 'Plot':{ color:'#8b5cf6', linewidth:2 } } },
    { id:'StochasticRSI@tv-basicstudies', inputs:{ lengthRSI:14, lengthStoch:14, smoothK:3, smoothD:3 } },
  ]));

  wrap.innerHTML = `
    <iframe
      src="https://www.tradingview.com/widgetsnippet/symbol-overview/?symbols=BIST%3A${ticker}&interval=${interval}&theme=${theme}&style=1&locale=tr&toolbar_bg=%23${dark?'1c1c1a':'ffffff'}&enable_publishing=false&hide_side_toolbar=false&allow_symbol_change=false&studies=%5B%22MAExp%40tv-basicstudies%22%2C%22MAExp%40tv-basicstudies%22%2C%22StochasticRSI%40tv-basicstudies%22%5D&no_referral_id=1"
      style="width:100%;height:100%;border:none;border-radius:12px"
      allowtransparency="true"
      frameborder="0"
    ></iframe>`;

  // Fallback: TradingView Mini Widget (her zaman çalışır)
  // Eğer iframe yüklenmezse basit widget göster
  const iframe = wrap.querySelector('iframe');
  iframe.onerror = () => loadFallbackChart(ticker, interval);

  // 3 saniye sonra yüklenmediyse fallback
  setTimeout(() => {
    try {
      if (iframe.contentDocument && iframe.contentDocument.body.innerHTML === '') {
        loadFallbackChart(ticker, interval);
      }
    } catch { /* cross-origin, normal */ }
  }, 3000);
}

function loadFallbackChart(ticker, interval) {
  const wrap = document.getElementById('tv-chart-wrap');
  const dark  = document.body.classList.contains('dark');
  const theme = dark ? 'dark' : 'light';
  const sym   = `BIST:${ticker}`;

  wrap.innerHTML = '';

  const script = document.createElement('script');
  script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
  script.async = true;
  script.innerHTML = JSON.stringify({
    autosize: true,
    symbol: sym,
    interval: interval,
    timezone: 'Europe/Istanbul',
    theme: theme,
    style: '1',
    locale: 'tr',
    enable_publishing: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
    studies: [
      'MAExp@tv-basicstudies',
      'MAExp@tv-basicstudies',
      'StochasticRSI@tv-basicstudies',
    ],
    studies_overrides: {
      'moving average exponential.length': 50,
    },
    container_id: 'tv-chart-wrap',
  });

  const container = document.createElement('div');
  container.className = 'tradingview-widget-container';
  container.style.cssText = 'width:100%;height:100%';
  const inner = document.createElement('div');
  inner.id = 'tv-chart-inner';
  inner.style.cssText = 'width:100%;height:100%';
  container.appendChild(inner);
  container.appendChild(script);
  wrap.appendChild(container);
}

function setChartInterval(interval, el) {
  state.chartInterval = interval;
  document.querySelectorAll('.ctab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  if (state.chartTicker) loadTVChart(state.chartTicker.ticker, interval);
}

function closeChart(e) {
  if (!e || e.target === document.getElementById('chart-bg')) {
    document.getElementById('chart-bg').classList.remove('open');
    // iframe'i temizle (bellek)
    setTimeout(() => { document.getElementById('tv-chart-wrap').innerHTML = ''; }, 300);
  }
}

function chartOpenPos() {
  if (!state.chartTicker) return;
  closeChart();
  setTimeout(() => openModal(state.chartTicker.ticker, state.chartTicker.price, state.chartTicker.k, state.chartTicker.d), 350);
}

function chartAddWatch() {
  if (!state.chartTicker) return;
  addToWatchlist(state.chartTicker.ticker, state.chartTicker.price, state.chartTicker.k, state.chartTicker.d);
}

// ── FILTER ────────────────────────────────────────────────────
function filterSignals(f, el) {
  state.filter = f;
  document.querySelectorAll('.fpill').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  renderSignals();
}

// ── FETCH ─────────────────────────────────────────────────────
async function fetchSignals() {
  const btn = document.querySelector('.refresh-btn');
  if (btn) btn.innerHTML = '<i class="fa-solid fa-rotate-right fa-spin"></i> Güncelleniyor...';

  try {
    const url = state.settings.backendUrl;
    if (!url) throw new Error('no-backend');
    const res = await fetch(`${url}/signals`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error('fail');
    const data = await res.json();
    state.signals = data.signals || [];
    setOnline(true);
    showToast(`${state.signals.length} sinyal yüklendi`);
  } catch {
    state.signals = DEMO;
    setOnline(false);
  }

  // Bugünün sinyallerini arşive ekle
  archiveToday();
  renderSignals();
  if (btn) btn.innerHTML = '<i class="fa-solid fa-rotate-right"></i> Güncelle';
}

function setOnline(on) {
  document.getElementById('status-dot').classList.toggle('offline', !on);
}

function updateLastUpdate() {
  const el = document.getElementById('last-update');
  if (el) el.textContent = 'Son: ' + new Date().toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'});
}

// ── ARŞİV ─────────────────────────────────────────────────────
function archiveToday() {
  if (!state.signals.length) return;
  const today = todayStr();
  let archive = state.archive;
  const existing = archive.find(a => a.date === today);
  const sigData = state.signals.map(s => ({
    ticker: s.ticker, price: s.price, k: s.k, d: s.d, chg: s.chg,
    sector: s.sector, name: s.name, gainSince: null, addedAt: Date.now(),
  }));

  if (!existing) {
    archive.unshift({ date: today, signals: sigData });
    if (archive.length > 60) archive = archive.slice(0, 60); // 60 gün sakla
    state.archive = archive;
    DB.set('archive', archive);
  }
}

function renderArchive() {
  const container = document.getElementById('archive-list');
  // Demo arşivi gerçek arşivle birleştir
  const allArchive = [...state.archive];
  DEMO_ARCHIVE.forEach(da => {
    if (!allArchive.find(a => a.date === da.date)) allArchive.push(da);
  });
  allArchive.sort((a, b) => {
    const da = a.date.split('.').reverse().join('');
    const db = b.date.split('.').reverse().join('');
    return db.localeCompare(da);
  });

  let total = 0, gainSum = 0, gainCount = 0;
  allArchive.forEach(day => {
    total += day.signals.length;
    day.signals.forEach(s => {
      if (s.gainSince !== null && s.gainSince !== undefined) {
        gainSum += s.gainSince; gainCount++;
      }
    });
  });

  document.getElementById('arch-total').textContent = total;
  document.getElementById('arch-avg').textContent = gainCount ? '+' + (gainSum/gainCount).toFixed(1)+'%' : '—';

  if (!allArchive.length) {
    container.innerHTML = `<div class="empty"><i class="fa-solid fa-clock-rotate-left"></i><strong>Arşiv boş</strong>Her gün sinyaller buraya kaydedilir.</div>`;
    return;
  }

  container.innerHTML = allArchive.map(day => {
    const rows = day.signals.map((s,i) => {
      const hasGain = s.gainSince !== null && s.gainSince !== undefined;
      const gainHtml = hasGain
        ? `<div class="arch-pct ${s.gainSince >= 0 ? 'up' : 'dn'}">${s.gainSince >= 0 ? '+' : ''}${s.gainSince.toFixed(1)}%</div>
           <div class="arch-days">sinyal sonrası</div>`
        : `<div class="arch-pending">Takipte...</div>`;

      return `
        <div class="arch-item ${s.k < 10 ? 'hot' : 'warm'}">
          <div class="arch-ticker">${s.ticker}</div>
          <div class="arch-meta">
            ₺${s.price.toFixed(2)} · K: ${s.k.toFixed(1)} · ${s.sector}<br>
            <span style="display:flex;gap:3px;margin-top:3px">${strengthDots(s.k)}</span>
          </div>
          <div class="arch-result">${gainHtml}</div>
        </div>`;
    }).join('');

    return `
      <div class="arch-day">
        <div class="arch-day-label">${day.date} — ${day.signals.length} sinyal</div>
        ${rows}
      </div>`;
  }).join('');
}

// ── MODAL ─────────────────────────────────────────────────────
function openModal(ticker, price, k, d) {
  state.currentModal = { ticker, price, k, d };
  state.editIndex = null;
  document.getElementById('modal-ticker').textContent = `${ticker} — Pozisyon Aç`;
  document.getElementById('modal-sub').textContent    = 'Gerçek alım bilgilerini gir';
  const tPct = state.settings.defaultTarget / 100;
  const sPct = state.settings.defaultStop   / 100;
  document.getElementById('inp-price').value  = price.toFixed(2);
  document.getElementById('inp-lots').value   = '';
  document.getElementById('inp-target').value = (price * (1 + tPct)).toFixed(2);
  document.getElementById('inp-stop').value   = (price * (1 - sPct)).toFixed(2);
  const btn = document.getElementById('modal-save-btn');
  btn.innerHTML  = '<i class="fa-solid fa-check"></i> Pozisyon Aç';
  btn.onclick = savePosition;
  updatePreview();
  document.getElementById('modal-bg').classList.add('open');
}

function openEditModal(idx) {
  const p = state.positions[idx];
  state.currentModal = { ticker:p.ticker, price:p.entry, k:p.k, d:p.d };
  state.editIndex = idx;
  document.getElementById('modal-ticker').textContent = `${p.ticker} — Düzenle`;
  document.getElementById('modal-sub').textContent    = 'Hedef veya stop güncelle';
  document.getElementById('inp-price').value  = p.entry.toFixed(2);
  document.getElementById('inp-lots').value   = p.lots;
  document.getElementById('inp-target').value = p.target.toFixed(2);
  document.getElementById('inp-stop').value   = p.stop.toFixed(2);
  const btn = document.getElementById('modal-save-btn');
  btn.innerHTML = '<i class="fa-solid fa-check"></i> Güncelle';
  btn.onclick   = saveEditPosition;
  updatePreview();
  document.getElementById('modal-bg').classList.add('open');
}

function closeModal(e) {
  if (!e || e.target === document.getElementById('modal-bg'))
    document.getElementById('modal-bg').classList.remove('open');
}

function updatePreview() {
  const price  = parseFloat(document.getElementById('inp-price').value)  || 0;
  const lots   = parseFloat(document.getElementById('inp-lots').value)   || 0;
  const target = parseFloat(document.getElementById('inp-target').value) || 0;
  const stop   = parseFloat(document.getElementById('inp-stop').value)   || 0;
  document.getElementById('prev-cost').textContent   = lots   ? '₺'+(price*lots).toLocaleString('tr-TR',{maximumFractionDigits:0}) : '—';
  document.getElementById('prev-target').textContent = target ? '+'+((target-price)/price*100).toFixed(1)+'%' : '—';
  document.getElementById('prev-stop').textContent   = stop   ? '-'+((price-stop)/price*100).toFixed(1)+'%'  : '—';
}

// ── SAVE / EDIT POZİSYON ──────────────────────────────────────
function savePosition() {
  const price  = parseFloat(document.getElementById('inp-price').value);
  const lots   = parseFloat(document.getElementById('inp-lots').value);
  const target = parseFloat(document.getElementById('inp-target').value);
  const stop   = parseFloat(document.getElementById('inp-stop').value);
  if (!price || !lots) { showToast('⚠️ Fiyat ve adet girilmeli'); return; }
  const sig = state.signals.find(s => s.ticker === state.currentModal.ticker) || {};
  state.positions.push({
    ticker: state.currentModal.ticker,
    name:   sig.name || state.currentModal.ticker,
    entry: price, curr: sig.price || price,
    lots, target: target||price*1.12, stop: stop||price*0.93,
    k: state.currentModal.k, d: state.currentModal.d,
    date: new Date().toLocaleDateString('tr-TR',{day:'2-digit',month:'2-digit'}),
    openedAt: Date.now(),
  });
  DB.set('positions', state.positions);
  document.getElementById('modal-bg').classList.remove('open');
  showToast(`✅ ${state.currentModal.ticker} pozisyonu açıldı`);
  renderPortfolio(); updateBadge();
  sw('portfolio', document.querySelectorAll('.tab')[1]);
}

function saveEditPosition() {
  const idx = state.editIndex;
  if (idx===null) return;
  const p = state.positions[idx];
  p.entry  = parseFloat(document.getElementById('inp-price').value)  || p.entry;
  p.lots   = parseFloat(document.getElementById('inp-lots').value)   || p.lots;
  p.target = parseFloat(document.getElementById('inp-target').value) || p.target;
  p.stop   = parseFloat(document.getElementById('inp-stop').value)   || p.stop;
  DB.set('positions', state.positions);
  document.getElementById('modal-bg').classList.remove('open');
  showToast('✅ Pozisyon güncellendi');
  renderPortfolio();
}

function closePosition(idx) {
  const p = state.positions[idx];
  const pnlPct = ((p.curr-p.entry)/p.entry*100).toFixed(2);
  if (!confirm(`${p.ticker} pozisyonunu kapat?\nPnL: ${pnlPct>=0?'+':''}${pnlPct}%`)) return;
  state.positions.splice(idx,1);
  DB.set('positions', state.positions);
  showToast(`${p.ticker} kapatıldı`);
  renderPortfolio(); updateBadge();
}

// ── RENDER PORTFOLIO ──────────────────────────────────────────
function renderPortfolio() {
  const summary   = document.getElementById('portfolio-summary');
  const container = document.getElementById('portfolio-list');
  const pos = state.positions;

  if (!pos.length) {
    summary.innerHTML = '';
    container.innerHTML = `<div class="empty"><i class="fa-solid fa-briefcase"></i><strong>Henüz pozisyon yok</strong>Sinyaller sekmesinden "Pozisyon Aç" butonuna bas.</div>`;
    return;
  }

  let tCost=0, tVal=0;
  pos.forEach(p => { tCost += p.entry*p.lots; tVal += (p.curr||p.entry)*p.lots; });
  const tPnl = tVal - tCost;
  const tPct = (tPnl/tCost*100).toFixed(2);

  summary.innerHTML = `
    <div class="stat2">
      <div class="scard"><div class="scard-label">Toplam maliyet</div>
        <div class="scard-val" style="font-size:18px">₺${tCost.toLocaleString('tr-TR',{maximumFractionDigits:0})}</div></div>
      <div class="scard"><div class="scard-label">Toplam kâr/zarar</div>
        <div class="scard-val ${tPnl>=0?'g':'r'}" style="font-size:18px">
          ${tPnl>=0?'+':''}₺${Math.abs(tPnl).toLocaleString('tr-TR',{maximumFractionDigits:0})}
        </div>
        <div class="scard-sub">${tPct>=0?'+':''}${tPct}%</div></div>
    </div>`;

  container.innerHTML = pos.map((p,i) => {
    const curr   = p.curr || p.entry;
    const pnl    = (curr - p.entry) * p.lots;
    const pnlPct = ((curr-p.entry)/p.entry*100).toFixed(2);
    const profit = curr >= p.entry;
    const range  = p.target - p.stop;
    const prog   = range > 0 ? Math.min(100,Math.max(0,(curr-p.stop)/range*100)).toFixed(0) : 50;
    return `
    <div class="pos-card ${profit?'profit':'loss'}">
      <div class="pos-top">
        <div>
          <div class="pos-ticker">${p.ticker}</div>
          <div class="pos-lots">${p.lots.toLocaleString()} adet · Giriş: ₺${p.entry.toFixed(2)} · ${p.date}</div>
        </div>
        <div>
          <div class="pos-pnl ${profit?'up':'dn'}">${pnl>=0?'+':''}₺${Math.abs(pnl).toLocaleString('tr-TR',{maximumFractionDigits:0})}</div>
          <div class="pos-pnl-sub">${pnlPct>=0?'+':''}${pnlPct}%</div>
        </div>
      </div>
      <div class="pos-grid">
        <div class="pg-item"><div class="pg-label">Güncel</div><div class="pg-val">₺${curr.toFixed(2)}</div></div>
        <div class="pg-item"><div class="pg-label">Hedef</div><div class="pg-val g">₺${p.target.toFixed(2)}</div></div>
        <div class="pg-item"><div class="pg-label">Stop</div><div class="pg-val r">₺${p.stop.toFixed(2)}</div></div>
      </div>
      <div class="prog-wrap"><div class="prog-fill ${profit?'profit':'loss'}" style="width:${prog}%"></div></div>
      <div class="prog-labels"><span>Stop ₺${p.stop.toFixed(2)}</span><span>Hedef ₺${p.target.toFixed(2)}</span></div>
      <div class="pos-bottom">
        <div class="stoch-pills"><span class="sp">K: ${p.k.toFixed(1)}</span><span class="sp">D: ${p.d.toFixed(1)}</span></div>
        <div class="pos-actions">
          <span class="pos-btn edit" onclick="openEditModal(${i})">Düzenle</span>
          <span class="pos-btn close" onclick="closePosition(${i})">Kapat</span>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ── WATCHLIST ─────────────────────────────────────────────────
function addToWatchlist(ticker, price, k, d) {
  if (state.watchlist.find(w => w.ticker === ticker)) { showToast(`${ticker} zaten izlemede`); return; }
  const sig = state.signals.find(s => s.ticker === ticker) || {};
  state.watchlist.push({
    ticker, name: sig.name||ticker, price, entry: price,
    target: price*(1+state.settings.defaultTarget/100),
    stop:   price*(1-state.settings.defaultStop/100),
    k, d, addedAt: new Date().toLocaleDateString('tr-TR',{day:'2-digit',month:'2-digit'}),
  });
  DB.set('watchlist', state.watchlist);
  showToast(`👁 ${ticker} izlemeye eklendi`);
}

// ── GAINERS ───────────────────────────────────────────────────
function renderGainers() {
  // Arşivden ve demo'dan tüm sonuçları topla
  const allArchive = [...state.archive];
  DEMO_ARCHIVE.forEach(da => { if (!allArchive.find(a=>a.date===da.date)) allArchive.push(da); });

  const results = [];
  allArchive.forEach(day => {
    day.signals.forEach(s => {
      if (s.gainSince !== null && s.gainSince !== undefined) {
        results.push({ ticker:s.ticker, maxGain:s.gainSince, entry:s.price, date:day.date });
      }
    });
  });

  results.sort((a,b) => b.maxGain - a.maxGain);

  // scroll
  document.getElementById('gainers-scroll').innerHTML = results.slice(0,8).map(h => `
    <div class="gc">
      <div class="gc-tick">${h.ticker}</div>
      <div class="gc-pct up">+${h.maxGain.toFixed(1)}%</div>
      <div class="gc-from">${h.date}</div>
    </div>
  `).join('') || '<div style="color:var(--text3);font-size:12px;padding:8px">Henüz veri yok</div>';

  const total = results.length;
  const wins  = results.filter(r => r.maxGain >= 3).length;
  document.getElementById('win-rate').textContent = total ? Math.round(wins/total*100)+'%' : '—';
  document.getElementById('avg-gain').textContent = total ? '+'+(results.reduce((s,r)=>s+r.maxGain,0)/total).toFixed(1)+'%' : '—';

  document.getElementById('history-table').innerHTML = `
    <div class="table-head"><span>HİSSE</span><span>GİRİŞ</span><span>YÜKSELIŞ</span><span>TARİH</span></div>
    ${results.slice(0,12).map(h => `
    <div class="table-row">
      <span style="font-weight:600;color:var(--text)">${h.ticker}</span>
      <span style="color:var(--text2)">₺${h.entry.toFixed(2)}</span>
      <span class="up" style="font-weight:600">+${h.maxGain.toFixed(1)}%</span>
      <span style="color:var(--text2)">${h.date}</span>
    </div>`).join('')}
  `;
}

// ── NAVIGATION ────────────────────────────────────────────────
function sw(id, el, type='tab') {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('p-'+id).classList.add('active');
  if (type==='tab') {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    const pages=['signals','portfolio','archive','gainers'];
    document.querySelectorAll('.ni').forEach((n,i) => n.classList.toggle('active', pages[i]===id));
  } else {
    document.querySelectorAll('.ni').forEach(n => n.classList.remove('active'));
    el.classList.add('active');
    const pages=['signals','portfolio','archive','gainers'];
    const idx=pages.indexOf(id);
    document.querySelectorAll('.tab').forEach((t,i) => t.classList.toggle('active', i===idx));
  }
  if (id==='gainers') renderGainers();
  if (id==='archive') renderArchive();
}

function updateBadge() {
  const b=document.getElementById('portfolio-badge');
  b.textContent=state.positions.length;
  b.style.display=state.positions.length>0?'block':'none';
}

// ── SETTINGS ─────────────────────────────────────────────────
function openSettings() {
  document.getElementById('settings-url').value    = state.settings.backendUrl||'';
  document.getElementById('settings-target').value = state.settings.defaultTarget;
  document.getElementById('settings-stop').value   = state.settings.defaultStop;
  document.getElementById('settings-bg').classList.add('open');
}
function closeSettings(e) {
  if (!e || e.target===document.getElementById('settings-bg'))
    document.getElementById('settings-bg').classList.remove('open');
}
function saveSettings() {
  state.settings.backendUrl     = document.getElementById('settings-url').value.trim().replace(/\/$/,'');
  state.settings.defaultTarget  = parseFloat(document.getElementById('settings-target').value)||12;
  state.settings.defaultStop    = parseFloat(document.getElementById('settings-stop').value)||7;
  DB.set('settings', state.settings);
  document.getElementById('settings-bg').classList.remove('open');
  showToast('✅ Ayarlar kaydedildi');
  fetchSignals();
}

// ── TOAST ─────────────────────────────────────────────────────
let _tt;
function showToast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t=document.createElement('div'); t.className='toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(_tt);
  _tt = setTimeout(() => t.classList.remove('show'), 2800);
}

// ── AUTO REFRESH ──────────────────────────────────────────────
setInterval(() => { if (state.settings.backendUrl) fetchSignals(); }, 5*60*1000);

// ── PWA ───────────────────────────────────────────────────────
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});

// ── INIT ──────────────────────────────────────────────────────
// Handle return from chart.html
const chartAction = localStorage.getItem('chart_action');
if (chartAction) {
  try {
    const ca = JSON.parse(chartAction);
    localStorage.removeItem('chart_action');
    setTimeout(() => {
      if (ca.action === 'pos') openModal(ca.ticker, ca.price, ca.k, ca.d);
      else if (ca.action === 'watch') addToWatchlist(ca.ticker, ca.price, ca.k, ca.d);
    }, 400);
  } catch {}
}

applyTheme(state.theme);
fetchSignals();
renderPortfolio();
updateBadge();
